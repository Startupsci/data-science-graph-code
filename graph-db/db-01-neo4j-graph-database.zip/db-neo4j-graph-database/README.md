# Data Science Graph

[Data Science Solutions](https://startupsci.com) book

[![Data Science Solutions book](https://github.com/Startupsci/data-science-notebooks/blob/master/dss-cover-300.jpg "Data Science Solutions book")](https://startupsci.com/)

Neo4j Graph Database created in the Data Science Book.

Login: neo4j | Password: demo
